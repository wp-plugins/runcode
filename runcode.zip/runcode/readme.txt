=== Plugin Name ===
Contributors: Sunshow
Donate link: http://blog.sunshow.net/archives/367.html
Tags: code
Requires at least: 2.0.2
Tested up to: 2.6
Stable tag: trunk

A plugin for WordPress, which can be used to show your code.

== Description ==

A plugin for WordPress, which can be used to show your code.

== Installation ==

1. Extract and upload `runcode.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's all

== Frequently Asked Questions ==

Null.

== Screenshots ==

Watch a demo here:
http://blog.sunshow.net/archives/367.html

== A Example ==

&lt;runcode&gt;
&lt;script&gt;
window.alert("Hello world!");
&lt;/script&gt;
&lt;p&gt;You can change the code before run.&lt;/p&gt;
&lt;/runcode&gt;

== Change Log ==

v1.0
Add multi-language support.
Add new feature: copy to clipboard.